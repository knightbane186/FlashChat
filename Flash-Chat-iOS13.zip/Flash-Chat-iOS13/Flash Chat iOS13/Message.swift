//
//  Message.swift
//  Flash Chat iOS13
//
//  Created by Denver Lopes on 29/8/22.
//

import Foundation


struct Message {
    let sender: String
    let body: String
}
